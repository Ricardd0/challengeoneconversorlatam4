package miPrimerFrame;

import java.awt.EventQueue;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.json.simple.parser.ParseException;

public class Principal {
	
	public static void main(String[] args) throws UnsupportedEncodingException, ParseException, IOException {

		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ventana frame = new ventana();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		Logico logic = new Logico();
		logic.miFuncion2();
		//ConsumiendoApi MyApi = new ConsumiendoApi();
		//MyApi.maint();
		
		
		
		
		DatosIngresados datosUsuario = new DatosIngresados();
		datosUsuario.datoIn();
		
		
	}

}
