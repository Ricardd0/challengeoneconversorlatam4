package miPrimerFrame;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.json.simple.parser.ParseException;

public class Logico {
	public static double cantidadLeida;
	private double cantidadInicial;
	public  double cantidad;
	public double indice;
	public double cantidadAbajo;
	
	public double miFuncion(double indice) throws UnsupportedEncodingException, ParseException, IOException {
	ConsumiendoApi n = new ConsumiendoApi();
	n.maint();
	//ventana v = new ventana();
	//v.ventana1();
	//indice = v.getindicePreInicial();
	switch((int)indice) {
	  case 0:
		  cantidadLeida = n.getpesoMexicano();
	    break;
	  case 1:
		  cantidadLeida = n.getDolarAustraliano();
	    break;
	  case 2:
		  cantidadLeida = n.getrealBrasileno();
	    break;
	  case 3:
		  cantidadLeida = n.getLevBulgaria();
	    break;
	  case 4:
		  cantidadLeida = n.getdolarCanadiense();
	    break;
	  case 5:
		  cantidadLeida = n.getfrancoSuizo();
	    break;
	  case 6:
		  cantidadLeida = n.getyuanChino();
	    break;
	  case 7:
		  cantidadLeida = n.getcoronaRepChe();
	    break;
	  case 8:
		  cantidadLeida = n.getcoronaDanesa();
	    break;
	  case 9:
		  cantidadLeida = n.getlibraEsterlina();
	    break;
	  case 10:
		  cantidadLeida = n.getdolarHongKong();
	    break;
	  case 11:
		  cantidadLeida = n.getforintoHungaro();
	    break;
	  case 12:
		  cantidadLeida = n.getrupiaIndonesia();
	    break;
	  case 13:
		  cantidadLeida = n.getshekelIsraeli();
	    break;
	  case 14:
		  cantidadLeida = n.getrupiaIndia();
	    break;
	  case 15:
		  cantidadLeida = n.getcoronaIslandesa();
	    break;
	  case 16:
		  cantidadLeida = n.getyenJapones();
	    break;
	  case 17:
		  cantidadLeida = n.getwonSurcoreano();
	    break;
	  case 18:
		  cantidadLeida = n.getringgitMalayo();
	    break;
	  case 19:
		  cantidadLeida = n.getcoronaNoruega();
	    break;
	  case 20:
		  cantidadLeida = n.getdolarNeoselandes();
	    break;
	  case 21:
		  cantidadLeida = n.getpesoFilipino();
	    break;
	  case 22:
		  cantidadLeida = n.getestolyPolaco();
	    break;
	  case 23:
		  cantidadLeida = n.getleuRomano();
	    break;
	  case 24:
		  cantidadLeida = n.getcoronaSueca();
	    break;
	  case 25:
		  cantidadLeida = n.getdolarSingapur();
	    break;
	  case 26:
		  cantidadLeida = n.getbathTailandes();
	    break;
	  case 27:
		  cantidadLeida = n.getliraTurca();
	    break;
	  case 28:
		  cantidadLeida = n.getdolarEEUU();
	    break;
	  case 29:
		  cantidadLeida = n.getrandSudafricano();
	    break;
	    
	  default:
		  cantidadLeida = 0;
	    
	}
	return cantidadLeida;
	
	
	
	}
	
	public double miFuncion2() throws UnsupportedEncodingException, ParseException, IOException {
		ventana v = new ventana();
		indice = v.getindicePreInicial();
		System.out.println("el indice 1 es " + indice);
		miFuncion(indice);
		
		
		cantidadInicial= cantidadLeida;
		
		indice = v.getindicePaisesAbajo()+1.0;
		miFuncion(indice);
		cantidadAbajo = cantidadLeida;
		cantidad=(cantidadAbajo/cantidadInicial)*(v.monto);
		v.textFieldCantidad.setText(String.valueOf(cantidadInicial));
		v.textFieldMensaje.setText(String.valueOf(v.monto)+" "+ v.itemSeleccionado + " es igual a " + String.valueOf(cantidad) +" " + v.getitemseleccionadoAb());
		return cantidadLeida;
	}
	
	
	
	
}

	
	
	

