package miPrimerFrame;


import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.json.simple.parser.ParseException;

import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.AbstractListModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.awt.event.ActionEvent;

public class ventana extends JFrame {
	
	public static JPanel contentPane;
	//private static  JTextField textFieldUnitario;
	public JTextField textFieldCantidad;
	private JTextField textFieldBanderaUp;
	private JTextField textFieldBanderaAbajo;
	private static  JTextField textFieldMonto;
	private JTextField textFieldFecha;
	public JTextField textFieldMensaje;
	public double monto=1;
	public String itemSeleccionado;
	public String itemseleccionadoAb;
	//private double cantidadInicial;
	private int indicePreInicial;
	//public static double cantidadLeida;
	//public static double cantidad;
	//public double cantidadAbajo;
	private  int indicePaisesAbajo;

	/**
	 * Launch the application.
	 */


	/**
	 * Create the frame.
	 * @throws IOException 
	 * @throws ParseException 
	 * @throws UnsupportedEncodingException 
	 */
	
	public ventana() throws UnsupportedEncodingException, ParseException, IOException {
		ConsumiendoApi n = new ConsumiendoApi();
		n.maint();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JComboBox<String> comboBoxPreInicial = new JComboBox<String>();
		comboBoxPreInicial.setFont(new Font("Tahoma", Font.BOLD, 13));
		comboBoxPreInicial.setModel(new DefaultComboBoxModel(new String[] {"Peso Mexicano", "Dolar Australiano", "Lev Bulgaria", "Real Brasileño", "Dolar Canadiense", "Franco Suizo", "Renminbi Yuan Chino", "Corona Republica Checa", "Corona Danesa", "Euro Union Europea", "Libra Esterlina", "Dolar de Hong Kong", "Forinto Húngaro", "Rupia Indonesia", "Nuevo Shekel Israelí", "Rupia India", "Corona Islandesa", "Yen Japonés", "Won Surcoreano", "Ringgit Malayo", "Corona Noruega", "Dolar Neoselandés", "Peso Filipino", "Esloty Polaco", "Leu Romano", "Corona Sueca", "Dolar de Singapur", "Baht Tailandés", "Lira Turca", "Dolar Norteamericano", "Rand Sudafricano"}));
		comboBoxPreInicial.setBounds(110, 49, 154, 35);
		contentPane.add(comboBoxPreInicial);
		itemSeleccionado = (String) comboBoxPreInicial.getSelectedItem();
		indicePreInicial = comboBoxPreInicial.getSelectedIndex();
		
		JComboBox<String> comboBoxPaisesAbajo = new JComboBox<String>();
		comboBoxPaisesAbajo.setFont(new Font("Tahoma", Font.BOLD, 13));
		comboBoxPaisesAbajo.setModel(new DefaultComboBoxModel(new String[] {"Dolar Australiano", "Lev Bulgaria", "Real Brasileño", "Dolar Canadiense", "Franco Suizo", "Renminbi Yuan Chino", "Corona Republica Checa", "Corona Danesa", "Euro Union Europea", "Libra Esterlina", "Dolar de Hong Kong", "Forinto Húngaro", "Rupia Indonesia", "Nuevo Shekel Israelí", "Rupia India", "Corona Islandesa", "Yen Japonés", "Won Surcoreano", "Peso Mexicano", "Ringgit Malayo", "Corona Noruega", "Dolar Neoselandés", "Peso Filipino", "Esloty Polaco", "Leu Romano", "Corona Sueca", "Dolar de Singapur", "Baht Tailandés", "Lira Turca", "Dolar Norteamericano", "Rand Sudafricano"}));
		comboBoxPaisesAbajo.setBounds(110, 143, 154, 35);
		contentPane.add(comboBoxPaisesAbajo);
		itemseleccionadoAb = (String) comboBoxPaisesAbajo.getSelectedItem();
		indicePaisesAbajo = comboBoxPaisesAbajo.getSelectedIndex();
	
		textFieldCantidad = new JTextField();
		textFieldCantidad.setBounds(14, 144, 86, 35);
		contentPane.add(textFieldCantidad);
		textFieldCantidad.setColumns(10);
		//leer api
		//double cantidadLeida = n.getDolarAustraliano();
		//cantidad=cantidadLeida;
		//textFieldCantidad.setText(String.valueOf(cantidad));
		
		
		textFieldBanderaUp = new JTextField();
		textFieldBanderaUp.setBounds(274, 49, 69, 35);
		contentPane.add(textFieldBanderaUp);
		textFieldBanderaUp.setColumns(10);
		
		textFieldBanderaAbajo = new JTextField();
		textFieldBanderaAbajo.setBounds(274, 144, 69, 35);
		contentPane.add(textFieldBanderaAbajo);
		textFieldBanderaAbajo.setColumns(10);
		
		textFieldMonto = new JTextField();
		textFieldMonto.setBounds(14, 49, 86, 35);
		contentPane.add(textFieldMonto);
		textFieldMonto.setColumns(10);
		textFieldMonto.setText(String.valueOf(monto));
		
		textFieldFecha = new JTextField();
		textFieldFecha.setBounds(14, 228, 86, 20);
		contentPane.add(textFieldFecha);
		textFieldFecha.setColumns(10);
		
		//ConsumiendoApi n = new ConsumiendoApi();
		//n.maint();
		String fechaq = n.getFecha1();
		textFieldFecha.setText(fechaq);
		System.out.println(fechaq);
		System.out.println("hola");
		
		JButton RefreshButton = new JButton("REFRESH");
		RefreshButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		RefreshButton.setBounds(172, 227, 89, 23);
		contentPane.add(RefreshButton);
		
		textFieldMensaje = new JTextField();
		textFieldMensaje.setBounds(14, 11, 373, 20);
		contentPane.add(textFieldMensaje);
		textFieldMensaje.setColumns(10);
		
		//textFieldMensaje.setText(String.valueOf(monto)+" "+ itemSeleccionado + " es igual a " + cantidad +" " + itemseleccionadoAb);
		
	
		
		System.out.println(indicePreInicial);
		
		//Logico op = new Logico();
		//op.miFuncion(indicePreInicial);
		
		//cantidadInicial= cantidadLeida();
		//cantidad=(cantidadAbajo/cantidadInicial)*monto;
		//textFieldCantidad.setText(String.valueOf(cantidadInicial));
		//textFieldMensaje.setText(String.valueOf(monto)+" "+ itemSeleccionado + " es igual a " + String.valueOf(cantidad) +" " + itemseleccionadoAb);
		
		
		
	
	
}
	public double getindicePreInicial() {
		return indicePreInicial;
	}
	public  JTextField getTextFieldCantidad() {
		return textFieldCantidad;
	}
	public  JTextField getTextFieldMensaje() {
		return textFieldMensaje;
	}
	  public JTextField setTextFieldMensaje() {
	        this.textFieldMensaje = textFieldMensaje;
	        return textFieldMensaje;
	    }
	public  double getindicePaisesAbajo() {
		return indicePaisesAbajo;
	}
	public  double getmonto() {
		return monto;
	}
	public String getitemseleccionado() {
		return itemSeleccionado;
	}
	  public void setitemseleccionado() {
	        this.itemSeleccionado = itemSeleccionado;
	    }
	public String getitemseleccionadoAb() {
		return itemseleccionadoAb;
	}
	
	
	
	}
	


	


	

