package miPrimerFrame;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import org.json.*;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ConsumiendoApi {
	
	private String fecha1;
	private static double pesoMexicano, dolarAustraliano, levBulgaria, realBrasileno, dolarCanadiense, francoSuizo, yuanChino,
	coronaRepChe, coronaDanesa,libraEsterlina, dolarHongKong, forintoHungaro, rupiaIndonesia, shekelIsraeli, rupiaIndia, coronaIslandesa, 
	yenJapones, wonSurcoreano, ringgitMalayo, coronaNoruega, dolarNeoselandes, pesoFilipino, estolyPolaco, leuRomano,  coronaSueca, dolarSingapur, 
	bathTailandes, liraTurca, dolarEEUU, randSudafricano;
	  public void maint() throws ParseException, UnsupportedEncodingException, IOException  {
		URL url = new URL("https://api.frankfurter.app/latest");
		HttpURLConnection conn = (HttpURLConnection)url.openConnection();
		conn.addRequestProperty("User-Agent", "Chrome");
		conn.setRequestMethod("GET");
		Reader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
		StringBuilder sb = new StringBuilder();
	      for (int c; (c = in.read()) >= 0;)
	          sb.append((char)c);
	      System.out.println(sb);
	      //System.out.println(sb.toString()[2]);
	      String response = sb.toString();
	      //se crea el objeto que parseará la respuesta
	      JSONParser parser = new JSONParser();
	      //se parsea la respues en un JSONObject
	      JSONObject jsonResult = (JSONObject) parser.parse(response);
	      jsonResult = (JSONObject)jsonResult.get("rates");
	      
	      JSONObject fecha = (JSONObject) parser.parse(response);
	       fecha1 = (String) fecha.get("date");
	      //static  fecha2 = fecha1;
	   
	      
	  
	      
	      
	       pesoMexicano = (double) jsonResult.get("MXN");
	       dolarAustraliano = (double) jsonResult.get("AUD");
	       levBulgaria = (double) jsonResult.get("BGN");
	       realBrasileno = (double) jsonResult.get("BRL");
	       dolarCanadiense = (double) jsonResult.get("CAD");
	       francoSuizo = (double) jsonResult.get("CHF");
	       yuanChino = (double) jsonResult.get("CNY");
	       coronaRepChe = (double) jsonResult.get("CZK");
	      coronaDanesa = (double) jsonResult.get("DKK");
	      libraEsterlina = (double) jsonResult.get("GBP");
	      dolarHongKong = (double) jsonResult.get("HKD");
	      forintoHungaro = (double) jsonResult.get("HUF");
	      rupiaIndonesia = (long) jsonResult.get("IDR");
	      shekelIsraeli = (double) jsonResult.get("ILS");
	      rupiaIndia = (double) jsonResult.get("INR");
	      coronaIslandesa = (double) jsonResult.get("ISK");
	      yenJapones = (double) jsonResult.get("JPY");
	      wonSurcoreano = (double) jsonResult.get("KRW");
	      ringgitMalayo = (double) jsonResult.get("MYR");
	      coronaNoruega = (double) jsonResult.get("NOK");
	      dolarNeoselandes = (double) jsonResult.get("NZD");
	      pesoFilipino = (double) jsonResult.get("PHP");
	      estolyPolaco = (double) jsonResult.get("PLN");
	      leuRomano = (double) jsonResult.get("RON");
	      coronaSueca = (double) jsonResult.get("SEK");
	      dolarSingapur = (double) jsonResult.get("SGD");
	      bathTailandes = (double) jsonResult.get("THB");
	      liraTurca = (double) jsonResult.get("TRY");
	      dolarEEUU = (double) jsonResult.get("USD");
	      randSudafricano = (double) jsonResult.get("ZAR");
	      
	      
	      
	      
	      System.out.println(pesoMexicano);
	      System.out.println(fecha1);
	      //Class<? extends String> tipo = fecha1.getClass();
	      //System.out.println("El tipo de la variable es: " + tipo.getName());
	      
	      
	      
	      

	}
	  
	  public double getDolarAustraliano() {
		return dolarAustraliano;
	}


	public double getLevBulgaria() {
		return levBulgaria;
	}


	public String getFecha1() {
				return fecha1;	
	    }
	  public double getpesoMexicano() {
			return pesoMexicano;	
  }
	  public double getcoronaRepChe() {
			return coronaRepChe;	
  }
	  public double getfrancoSuizo() {
			return francoSuizo;	
}
	  public double getyuanChino() {
			return yuanChino;	
}
	  public double getdolarCanadiense() {
			return dolarCanadiense;	
}
	  public double getrealBrasileno() {
			return realBrasileno;	
}
	  public double getcoronaDanesa() {
			return coronaDanesa;	
}
	  public double getlibraEsterlina() {
			return libraEsterlina;	
}
	  public double getdolarHongKong() {
			return dolarHongKong;	
}
	  public double getforintoHungaro() {
			return forintoHungaro;	
}
	  public double getrupiaIndonesia() {
			return rupiaIndonesia;	
}
	  public double getrupiaIndia() {
			return rupiaIndia;	
}
	  public double getcoronaIslandesa() {
			return coronaIslandesa;	
}
	  public double getyenJapones() {
			return yenJapones;	
}
	  public double getwonSurcoreano() {
			return wonSurcoreano;	
}
	  public double getringgitMalayo() {
			return ringgitMalayo;	
}
	  public double getcoronaNoruega() {
			return coronaNoruega;	
}
	  public double getdolarNeoselandes() {
			return dolarNeoselandes;	
}
	  public double getpesoFilipino() {
			return pesoFilipino;	
}
	  public double getestolyPolaco() {
			return estolyPolaco;	
}
	  public double getleuRomano() {
			return leuRomano;	
}
	  public double getcoronaSueca() {
			return coronaSueca;	
}
	  public double getdolarSingapur() {
			return dolarSingapur;	
}
	  public double getbathTailandes() {
			return bathTailandes;	
}
	  public double getliraTurca() {
			return leuRomano;	
}
	  public double getdolarEEUU() {
			return dolarEEUU;	
}
	  public double getrandSudafricano() {
			return randSudafricano;	
}
	  public double getshekelIsraeli() {
			return shekelIsraeli;	
}
	  
	
	  
	 

}
