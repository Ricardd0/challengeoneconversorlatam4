package miPrimerFrame;

public class DatosIngresados {
	
	
	int valor1=1;
	int valor2=0;
	
	public  double datoIn() {
	//double	valor1 = Double.parseDouble(ventana.getTextFieldMonto().getText());
	//valor2 = Integer.valueOf(ventana.getTextFieldCantidad().getText());
	
	System.out.println(valor1);
	return valor1;
	//System.out.println(itemSeleccionado);
	
	}
	//String itemSeleccionado = (String) comboBoxPreInicial.getSelectedItem();
	

}
