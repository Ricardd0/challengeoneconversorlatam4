/**
 * 
*/
/**
 * @author Ricardo
 *
 */
module miPrimerFrame {
	requires java.desktop;
	requires json.simple;
}